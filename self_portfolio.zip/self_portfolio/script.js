var typed2 = new Typed('.text', {
    strings:[,' Developer--', ' Programmer--', ' Coder--'],
    typeSpeed:100,
    backSpeed:100,
    cursorChar:'',
    loop:true,
});
var typed2 = new Typed('.hero_text', {
    strings:[,' Developer--', ' Programmer--', ' Coder--'],
    typeSpeed:100,
    backSpeed:100,
    cursorChar:'',
    loop:true,
});
